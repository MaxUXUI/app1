package com.example.android.inventory;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.android.inventory.data.ProductContract.ProductEntry.COLUMN_PRODUCTNAME;
import static com.example.android.inventory.data.ProductContract.ProductEntry.COLUMN_PRODUCTPRICE;
import static com.example.android.inventory.data.ProductContract.ProductEntry.COLUMN_PRODUCTQUANTITY;

// This is a customized adapter for a list view that uses a cursor of product data
// It knows how to create list items for each row of product data

public class ProductCursorAdapter extends CursorAdapter {

// Constructor
    public ProductCursorAdapter(Context context, Cursor cursor){
        super(context, cursor, 0);
    }

// OVERRIDE NEW VIEW
    // Makes a new blank list item view. No data is set (or bound) to the views yet.
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {

        return LayoutInflater.from(context).inflate(R.layout.list_item, parent,false);
    }

// OVERRIDE BIND VIEW
    @Override
    public void bindView(View view, final Context context, Cursor cursor) {

        // Find fields to populate in inflated template
        TextView tvName = (TextView) view.findViewById(R.id.name);
        TextView tvPrice = (TextView) view.findViewById(R.id.price);
        //TextView tvQuantity = (TextView) view.findViewById(R.id.quantity);

        // Sale Button
        TextView saleView = (TextView) view.findViewById(R.id.sale);
        saleView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, R.string.sale_button_triggered, Toast.LENGTH_SHORT).show();
            }
        });

        // Extract properties from cursor
        String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PRODUCTNAME));
        int price = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_PRODUCTPRICE));
        //int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_PRODUCTQUANTITY));

        // Populate fields with extracted properties
        tvName.setText(name);
        tvPrice.setText(String.valueOf(price));

        int count = cursor.getColumnCount();
        Log.i(">>> COLUMNS LOG NAME ", Integer.toString(count));


//        if (cursor!=null) {
//            while (cursor.moveToNext()) {
//                for (int i =0 ; i< count; i++) {
//                    String data = cursor.getString(i);
//
//                }
//            }
//        }
    }
}
