package com.example.android.inventory.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static com.example.android.inventory.data.ProductContract.ProductEntry.COLUMN_PRODUCTNAME;
import static com.example.android.inventory.data.ProductContract.ProductEntry.COLUMN_PRODUCTPRICE;
import static com.example.android.inventory.data.ProductContract.ProductEntry.COLUMN_PRODUCTQUANTITY;
import static com.example.android.inventory.data.ProductContract.ProductEntry.COLUMN_SUPPLIERNAME;
import static com.example.android.inventory.data.ProductContract.ProductEntry.COLUMN_SUPPLIERPHONE;
import static com.example.android.inventory.data.ProductContract.ProductEntry._ID;
import static com.example.android.inventory.data.ProductContract.ProductEntry.TABLE_NAME;

public class ProductDbHelper extends SQLiteOpenHelper {

    // constants for db name and version

    public static final String DATABASE_NAME = "inventory.db";
    public static final int DATABASE_VERSION = 1;

    // constructor

    public ProductDbHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // CREATE TABLE Statement
        final String SQL_CREATE_PRODUCTS_TABLE =
                "CREATE TABLE " + TABLE_NAME + " ("
                        + _ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                        + COLUMN_PRODUCTNAME + " TEXT,"
                        + COLUMN_PRODUCTQUANTITY + " INTEGER,"
                        + COLUMN_PRODUCTPRICE + " INTEGER,"
                        + COLUMN_SUPPLIERNAME + " TEXT,"
                        + COLUMN_SUPPLIERPHONE + " TEXT"
                        + ");";

        db.execSQL(SQL_CREATE_PRODUCTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
