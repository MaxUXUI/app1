package com.example.android.inventory.data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

// Customized ContentProvider for this app
// Will handle permissions to apps that access the database

public class ProductProvider extends ContentProvider {

    // Tag for log messages
    public static final String LOG_TAG = ProductProvider.class.getSimpleName();

    // Setup UriMatcher
    private static final int PRODUCTS_CODE = 100;
    private static final int PRODUCTS_ID_CODE = 101;
    private static final UriMatcher sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        sUriMatcher.addURI(ProductContract.CONTENT_AUTHORITY, ProductContract.TABLENAME_PATH_PRODUCTS, PRODUCTS_CODE);
        sUriMatcher.addURI(ProductContract.CONTENT_AUTHORITY, ProductContract.TABLENAME_PATH_PRODUCTS + "/#", PRODUCTS_ID_CODE);
    }

    // Global database helper object
    private ProductDbHelper mDbHelper;

// OVERRIDE METHODS
// ****************

// ON CREATE
    // Initialize the provider and the database helper object
    @Override
    public boolean onCreate() {
        // initialize a ProductDbHelper object to gain access to the products database
        // Make sure the variable is a global variable, so it can be referenced from other ContentProvider methods
        mDbHelper = new ProductDbHelper(getContext());
        return true;
    }

// QUERY
    // Perform the query for the given URI. Use the given projection, selection, selection arguments, and sort order
    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        // Create and/or open a database to read from it
        SQLiteDatabase db = mDbHelper.getReadableDatabase();

        Cursor cursor;

        // setup uriMatcher
        // It matches the uri parameter of this method >>> public Cursor query(@NonNull Uri uri, .....
        int match = sUriMatcher.match(uri);
        switch (match){
            case PRODUCTS_CODE:
                // perform database query on products table
                cursor = db.query(ProductContract.ProductEntry.TABLE_NAME, projection,null,null,null,null,sortOrder);
                break;
            case PRODUCTS_ID_CODE:
                // SQL >> ... WHERE _ID = ...
                selection = ProductContract.ProductEntry._ID + "=?";
                // ContentUris.parseId(uri) will get the _ID
                selectionArgs = new String[] {String.valueOf(ContentUris.parseId(uri))};
                cursor = db.query(ProductContract.ProductEntry.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
                break;
            default:
                throw new IllegalArgumentException("Cannot query URI: " + uri);
        }

        // Set notification URI on the cursor
        // so we know what content URI the Cursor was created for
        // If the data at this URI changes, then we know we need to update the Cursor
        cursor.setNotificationUri(getContext().getContentResolver(), uri);

        return cursor;
    }

// INSERT
    // Insert new data into the provider with the given ContentValues
    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        // UriMatcher to figure out what pattern to follow (PRODUCTS_CODE or PRODUCTS_ID_CODE)
        // here only PRODUCTS_CODE is relevant
        final int match = sUriMatcher.match(uri);
        switch (match) {
            case PRODUCTS_CODE:
                return insertProduct(uri, contentValues);
            default:
                throw new IllegalArgumentException("Insertion is not supported for " + uri);
        }
    }
    // Helper method
    // Insert a product into the database with the given content values
    // Return the new content URI for that specific row in the database
    private Uri insertProduct(Uri uri, ContentValues values) {

        // TODO: Check INT and STRINGS **********

        // Check that Edit Texts and the STRINGS are not null
        String name = values.getAsString(ProductContract.ProductEntry.COLUMN_PRODUCTNAME);
        if (name == null) {
            throw new IllegalArgumentException("Product requires a name");
        }

        Integer quantity = values.getAsInteger(ProductContract.ProductEntry.COLUMN_PRODUCTQUANTITY);
        if (quantity == null || quantity < 0) {
            throw new IllegalArgumentException("Product requires a quantity");
        }

        Integer price = values.getAsInteger(ProductContract.ProductEntry.COLUMN_PRODUCTPRICE);
        if (price == null || price < 0) {
            throw new IllegalArgumentException("Product requires a price");
        }

        String supplierName = values.getAsString(ProductContract.ProductEntry.COLUMN_SUPPLIERNAME);
        if (supplierName == null) {
            throw new IllegalArgumentException("Product requires a supplier name");
        }

        String supplierPhone = values.getAsString(ProductContract.ProductEntry.COLUMN_SUPPLIERPHONE);
        if (supplierPhone == null) {
            throw new IllegalArgumentException("Product requires a supplier phone number");
        }

        // get writable database
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        // insert new product with the given values with this INSERT-DATABASE METHOD from the SQLiteDatabase.class
        long id = db.insert(ProductContract.ProductEntry.TABLE_NAME, null, values);
        // if the ID is -1, then the insertion failed. Log an error and return null.
        if (id == -1){
            Log.e(LOG_TAG, "Failed to insert row for " + uri);
        }

        // Notify all listeners that the data has changed for the product content URI
        // uri: content//com.example.android.inventory/products
        getContext().getContentResolver().notifyChange(uri, null);

        // Once we know the ID of the new row in the table,
        // return the new URI with the ID appended to the end of it
        return ContentUris.withAppendedId(uri, id);
    }

// UPDATE
    // Updates the data at the given selection and selection arguments, with the new ContentValues
    // returns int... int represents how many rows (entries) have been updated
    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        final int match = sUriMatcher.match(uri);
        switch (match) {
            case PRODUCTS_CODE:
                return updateProduct(uri, values, selection, selectionArgs);
            case PRODUCTS_ID_CODE:
                // For the PRODUCT_ID code, extract out the ID from the URI,
                // so we know which row to update. Selection will be "_id=?" and selection
                // arguments will be a String array containing the actual ID.
                selection = ProductContract.ProductEntry._ID + "=?";
                selectionArgs = new String[] { String.valueOf(ContentUris.parseId(uri)) };
                return updateProduct(uri, values, selection, selectionArgs);
            default:
                throw new IllegalArgumentException("Update is not supported for " + uri);
        }
    }
    // Update products in the database with the given content values. Apply the changes to the rows
    // specified in the selection and selection arguments (which could be 0 or 1 or more products).
    // Return the number of rows that were successfully updated
    private int updateProduct(Uri uri, ContentValues values, String selection, String[] selectionArgs) {

        // If the {@link ProductEntry#COLUMN_PRODUCTNAME} key is present, check that the name value is not null.
        if (values.containsKey(ProductContract.ProductEntry.COLUMN_PRODUCTNAME)) {
            String name = values.getAsString(ProductContract.ProductEntry.COLUMN_PRODUCTNAME);
            if (name == null) {
                throw new IllegalArgumentException("Product requires a name");
            }
        }
        if (values.containsKey(ProductContract.ProductEntry.COLUMN_PRODUCTQUANTITY)) {
            Integer quantity = values.getAsInteger(ProductContract.ProductEntry.COLUMN_PRODUCTQUANTITY);
            if (quantity == null) {
                throw new IllegalArgumentException("Product requires a quantity");
            }
        }
        if (values.containsKey(ProductContract.ProductEntry.COLUMN_PRODUCTPRICE)) {
            Integer price = values.getAsInteger(ProductContract.ProductEntry.COLUMN_PRODUCTPRICE);
            if (price == null) {
                throw new IllegalArgumentException("Product requires a price");
            }
        }
        if (values.containsKey(ProductContract.ProductEntry.COLUMN_SUPPLIERNAME)) {
            String supplierName = values.getAsString(ProductContract.ProductEntry.COLUMN_SUPPLIERNAME);
            if (supplierName == null) {
                throw new IllegalArgumentException("Product requires a supplier name");
            }
        }
        if (values.containsKey(ProductContract.ProductEntry.COLUMN_SUPPLIERPHONE)) {
            String supplierPhone = values.getAsString(ProductContract.ProductEntry.COLUMN_SUPPLIERPHONE);
            if (supplierPhone == null) {
                throw new IllegalArgumentException("Product requires a supplier phone");
            }
        }

        // If there are no values to update, then don't try to update the database
        if (values.size() == 0) {
            return 0;
        }

        // Otherwise, get writeable database to update the data
        SQLiteDatabase database = mDbHelper.getWritableDatabase();

        // Perform the update on the database and get the number of rows affected
        int rowsUpdated = database.update(ProductContract.ProductEntry.TABLE_NAME, values, selection,selectionArgs);

        if(rowsUpdated != 0){
            getContext().getContentResolver().notifyChange(uri, null);
        }

        return rowsUpdated;
    }

// DELETE
    // Delete the data at the given selection and selection arguments
    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        // track number of deleted rows
        int rowsDeleted;

        // Get writeable database
        SQLiteDatabase database = mDbHelper.getWritableDatabase();

        final int match = sUriMatcher.match(uri);
        switch (match) {
            case PRODUCTS_CODE:
                // Delete all rows that match the selection and selection args
                rowsDeleted = database.delete(ProductContract.ProductEntry.TABLE_NAME, selection, selectionArgs);
                break;
            case PRODUCTS_ID_CODE:
                // Delete a single row given by the ID in the URI
                selection = ProductContract.ProductEntry._ID + "=?";
                selectionArgs = new String[] { String.valueOf(ContentUris.parseId(uri)) };
                rowsDeleted = database.delete(ProductContract.ProductEntry.TABLE_NAME, selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Deletion is not supported for " + uri);
        }

        // if 1 or more rows were deleted, notify all listeners that the data at the given URI has changed
        if (rowsDeleted != 0){
            getContext().getContentResolver().notifyChange(uri,null);
        }

        return rowsDeleted;
    }

    // Returns the MIME type of data for the content URI
    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        final int match = sUriMatcher.match(uri);
        switch (match) {
            case PRODUCTS_CODE:
                return ProductContract.ProductEntry.CONTENT_LIST_TYPE;
            case PRODUCTS_ID_CODE:
                return ProductContract.ProductEntry.CONTENT_ITEM_TYPE;
            default:
                throw new IllegalStateException("Unknown URI " + uri + " with match " + match);
        }
    }
}
