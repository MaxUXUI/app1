package com.example.android.inventory.data;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

public final class ProductContract {

// Constructor
// ***********
    private ProductContract(){}

// CONSTANTS FOR THE URI
// *********************

    // Content Authority
    public static final String CONTENT_AUTHORITY = "com.example.android.inventory";

    // BASE URI: Scheme + CONTENT_AUTHORITY (this will be shared by every URI associated with ProductContract)
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    // TABLE_NAME
    // TODO: Maybe Check table name: products, inventory... ?
    public static final String TABLENAME_PATH_PRODUCTS = "products";


// PRODUCT ENTRIES
// ***************

    public static abstract class ProductEntry implements BaseColumns {

        // Lastly: BASE URI + TABLE_NAME
        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, TABLENAME_PATH_PRODUCTS);

        // The MIME type of the {@link #CONTENT_URI} for a list of products
        public static final String CONTENT_LIST_TYPE =
                ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + TABLENAME_PATH_PRODUCTS;

        // The MIME type of the {@link #CONTENT_URI} for a single product
        public static final String CONTENT_ITEM_TYPE =
                ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + TABLENAME_PATH_PRODUCTS;

        // constants for columns

        public static final String TABLE_NAME = "products";

        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_PRODUCTNAME = "name";
        public static final String COLUMN_PRODUCTQUANTITY = "quantity";
        public static final String COLUMN_PRODUCTPRICE = "price";
        public static final String COLUMN_SUPPLIERNAME = "suppliername";
        public static final String COLUMN_SUPPLIERPHONE = "supplierphone";
    }
}
