package com.example.android.inventory;

import android.app.LoaderManager;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.android.inventory.data.ProductContract;
import com.example.android.inventory.data.ProductContract.ProductEntry;

/**
 * Displays list of products that were entered and stored in the app.
 */
public class CatalogActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>{

    private static final int LOADER_ID = 0;

    ProductCursorAdapter mProductCursorAdapter;

// OVERRIDE
// ON CREATE
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);

        // Setup FAB to open EditorActivity
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CatalogActivity.this, EditorActivity.class);
                startActivity(intent);
            }
        });

        // Find the ListView which will be populated with the pet data
        ListView productListView = (ListView) findViewById(R.id.list_view);
        LinearLayout itemLinearLayout = (LinearLayout) findViewById(R.id.item_linearlayout);

        // Find and set empty view to ListView when list has 0 items
        View emptyView = findViewById(R.id.empty_view);
        productListView.setEmptyView(emptyView);

        // Setup an Adapter to create a list item for each row of pet data in the Cursor
        // There is no pet data yet (until loader finishes) so pass in null for the Cursor
        mProductCursorAdapter = new ProductCursorAdapter(this, null);
        productListView.setAdapter(mProductCursorAdapter);

        // Setup item click listener
        productListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
                Intent intent = new Intent(CatalogActivity.this, EditorActivity.class);

                // append the id to the content URI that represents the pet that was clicked on
                // e.g. if pet with ID = 2 is clicked on, the URI would be content://com.example.android.pets/pets/2
                Uri currentProductUri = ContentUris.withAppendedId(ProductEntry.CONTENT_URI, id);
                intent.setData(currentProductUri);
                startActivity(intent);
            }
        });

        // Kick off the loader
        getLoaderManager().initLoader(LOADER_ID, null, this);
    }

// OVERRIDE
// ON START
    // important to update row count !
    @Override
    protected void onStart() {
        super.onStart();
    }

// OVERRIDE
// ON CREATE OPTIONS MENU
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/menu_catalog.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate(R.menu.menu_catalog, menu);
        return true;
    }

// OVERRIDE
// ON OPTIONS ITEM SELECTED
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Insert dummy data" menu option
            case R.id.action_insert_dummy_data:
                insertData();
                return true;
            // Respond to a click on the "Delete all entries" menu option
            case R.id.action_delete_all_entries:
                deleteAllProducts();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

// method to Insert dummy Data
    private void insertData(){

        ContentValues values = new ContentValues();
        values.put(ProductEntry.COLUMN_PRODUCTNAME, "Iced tea");
        values.put(ProductEntry.COLUMN_PRODUCTQUANTITY, 10);
        values.put(ProductContract.ProductEntry.COLUMN_PRODUCTPRICE, 1);
        values.put(ProductEntry.COLUMN_SUPPLIERNAME, "The supplier that says Nee");
        values.put(ProductEntry.COLUMN_SUPPLIERPHONE, 4455667);

        // Insert a new row for Iced Tea into the provider using the ContentResolver
        // this is the INSERT-DATABASE METHOD from the ContentResolver.class
        Uri newUri = getContentResolver().insert(ProductEntry.CONTENT_URI, values);
    }

// Helper method to delete all pets in the database.
    private void deleteAllProducts() {
        int rowsDeleted = getContentResolver().delete(ProductEntry.CONTENT_URI, null, null);
        Log.v("CatalogActivity", rowsDeleted + " rows deleted from product database");
    }

// OVERRIDE
// onCreateLoader
    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        // PROJECTION that specifies the columns from the pets table >> in this case >> name and price
        String[] projection = {
                ProductEntry._ID,
                ProductEntry.COLUMN_PRODUCTNAME,
                ProductEntry.COLUMN_PRODUCTPRICE
        };

        // This loader will execute the ContentProviders query method on a background thread
        return new CursorLoader(this,
                ProductEntry.CONTENT_URI,
                projection,
                null,
                null,
                null);
    }

// OVERRIDE
// onLoadFinished
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        // Called when a previously created loader has finished loading
        // Swap the new cursor in. (The framework will take care of closing the
        // old cursor once we return.)
        mProductCursorAdapter.swapCursor(cursor);
    }

// OVERRIDE
// onLoaderReset
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // Called when a previously created loader is reset, making the data unavailable
        // This is called when the last Cursor provided to onLoadFinished()
        // above is about to be closed. We need to make sure we are no
        // longer using it.
        mProductCursorAdapter.swapCursor(null);
    }
}